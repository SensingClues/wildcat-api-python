import io

print(io.BytesIO(b"abc"))
